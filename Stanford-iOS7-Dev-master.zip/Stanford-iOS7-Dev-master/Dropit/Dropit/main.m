//
//  main.m
//  Dropit
//
//  Created by Mark Lewis on 15-8-10.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DropitAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DropitAppDelegate class]));
    }
}

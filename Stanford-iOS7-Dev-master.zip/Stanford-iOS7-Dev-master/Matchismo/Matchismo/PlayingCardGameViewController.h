//
//  PlayingCardGameViewController.h
//  Matchismo
//
//  Created by Mark Lewis on 15-7-29.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import "CardGameViewController.h"

@interface PlayingCardGameViewController : CardGameViewController

@end

//
//  PlayingCardDeck.h
//  Matchismo
//
//  Created by Mark Lewis on 15-7-9.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end

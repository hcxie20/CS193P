//
//  AttributorAppDelegate.h
//  Attributor
//
//  Created by Mark Lewis on 15-7-26.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttributorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

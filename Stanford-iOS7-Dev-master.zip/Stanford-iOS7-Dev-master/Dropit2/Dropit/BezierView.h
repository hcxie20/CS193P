//
//  BezierView.h
//  Dropit
//
//  Created by Mark Lewis on 15-8-14.
//  Copyright (c) 2015年 TechLewis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BezierView : UIView

@property (nonatomic, strong) UIBezierPath *path;

@end
